<nav class="bg-gray-800">
    <div class="flex justify-between px-5 py-4">
        <h1 class="font-bold text-white text-xl">Crendentials</h1>
        <a href="/logout" class="text-white">Logout</a>
    </div>
</nav>
