@extends('layouts.app')

@section('content')
    <section>
        <div class="flex gap-x-5">
            <button class="bg-blue-500 text-white rounded-md text-center px-10 py-3">All Credentials</button>
        <button>Store Credentials</button>
        </div>
    </section>
@endsection
